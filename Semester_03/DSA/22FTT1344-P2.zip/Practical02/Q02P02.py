class Queue:
    def __init__(self):
        self.items = []

    def is_empty(self):
        return self.items == []
    
    def enqueue(self, item):
        self.items.insert(0, item)
    
    def dequeue(self):
        if not self.is_empty():
            return self.items.pop()
        else:
            return None
    
    def remove_at_index(self, index):
        if index < len(self.items):
            self.items.pop(index)
    
    def size(self):
        return len(self.items)
    
    def print_queue(self):
        print(self.items)

class CounterQueueManager:
    def __init__(self):
        self.counter_queues = {1: Queue(), 2: Queue()}
    
    def enqueue(self, customer, counter_number):
        self.counter_queues[counter_number].enqueue(customer)
    
    def display_queues(self):
        for counter_number, queue in self.counter_queues.items():
            print(f"Counter {counter_number} queue order:", end=" ")
            queue.print_queue()



counter_queue_manager = CounterQueueManager()

counter_queue_manager.enqueue("Customer 1", 1)
counter_queue_manager.enqueue("Customer 2", 2)
counter_queue_manager.enqueue("Customer 3", 1)

counter_queue_manager.display_queues()
