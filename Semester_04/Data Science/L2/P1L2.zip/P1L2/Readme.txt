P1L2_01 - display name and age
P1L2_02 - score, 27 and avg score of all students
P1L2_03 - adding a new student
P1L2_04 - pair with 2 fliters for 1 visualization